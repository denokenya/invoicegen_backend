from django.contrib.auth.models import User
from django.db.models import fields
from rest_framework import serializers
from rest_framework.relations import HyperlinkedRelatedField, PrimaryKeyRelatedField
from api.models import *


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = "__all__"


class UserNoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserNote
        fields = "__all__"


class CompanySettingSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanySetting
        fields = "__all__"


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        exclude = ("password",)


class CompanySerializer(serializers.ModelSerializer):
    user = UserSerializer(many=False, read_only=True)
    settings = serializers.SerializerMethodField()
    address = AddressSerializer()

    class Meta:
        model = Company
        fields = "__all__"

    def get_settings(self, obj):
        if obj.companysetting_set.count() > 0:
            return CompanySettingSerializer(obj.companysetting_set.all()[0]).data
        else:
            return {}


class CompanyAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyAddress
        fields = "__all__"


class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = "__all__"


class CustomerAddressSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer()
    address = AddressSerializer()

    class Meta:
        model = CustomerAddress
        fields = "__all__"


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = "__all__"


class SaleOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = SaleOrder
        fields = "__all__"


class SaleOrderProductLineSerializer(serializers.ModelSerializer):
    saleOrder = serializers.PrimaryKeyRelatedField(queryset=SaleOrder.objects.all())

    class Meta:
        model = SaleOrderProductLine
        fields = "__all__"


class SaleOrderTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = SaleOrderTax
        fields = "__all__"


class InvoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invoice
        fields = "__all__"


class InvoiceTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceTax
        fields = "__all__"


class InvoiceProductLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceProductLine
        fields = "__all__"


class OutstandingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Outstanding
        fields = "__all__"


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = "__all__"


class IdsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ids
        fields = "__all__"


class IdsMapSerializer(serializers.ModelSerializer):
    ids = IdsSerializer()

    class Meta:
        model = IdsMap
        fields = "__all__"


class TaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tax
        fields = "__all__"
