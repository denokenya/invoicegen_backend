import json
from api.serializers import IdsSerializer, UserSerializer
from datetime import datetime, date
from django.db.models import Count
from .models import *


def jprint(d):
    return print(json.dumps(d, indent=4))


def formatint(n, leading_zeros_count=4):
    s = "{:0" + str(leading_zeros_count) + "}"
    return s.format(n)


def handleMask(mask, sep, data):
    mask = mask.replace("}{", "}" + sep + "{")
    return mask.format(**data)


def getTodayYearMonth():
    today = date.today()
    return [today, today.year, formatint(today.month, leading_zeros_count=2)]


ModelMapping = {
    "INVOICE": Invoice,
    "SALEORDER": SaleOrder,
    "CUSTOMER": Customer,
    "ADDRESS": Address,
    "PRODUCT": Product,
}

KeyName = {
    "INVOICE": "invoiceId",
    "SALEORDER": "saleOrderId",
    "CUSTOMER": "customerId",
    "ADDRESS": "code",
    "PRODUCT": "code",
}


def saleorder_id_gen():
    today, year, month = getTodayYearMonth()
    total_so = formatint(len(SaleOrder.objects.filter(date__month=month)) + 1)
    mask = Ids.objects.filter(name="SALEORDER")[0]
    filler = {
        "year": year,
        "month": month,
        "count": total_so,
        "prefix": mask.prefix,
    }
    current = handleMask(mask.mask, mask.sep, filler)
    mask.current = current
    filler["count"] = formatint(int(filler["count"]) + 1)
    upnext = handleMask(mask.mask, mask.sep, filler)
    mask.upnext = upnext
    mask.save()
    return [current, upnext]


def customer_id_gen():
    today, year, month = getTodayYearMonth()
    total_so = formatint(len(Customer.objects.filter(date__month=month)) + 1)
    mask = Ids.objects.filter(name="CUSTOMER")[0]
    filler = {
        "year": year,
        "month": month,
        "count": total_so,
        "prefix": mask.prefix,
    }
    current = handleMask(mask.mask, mask.sep, filler)
    mask.current = current
    filler["count"] = formatint(int(filler["count"]) + 1)
    upnext = handleMask(mask.mask, mask.sep, filler)
    mask.upnext = upnext
    mask.save()
    return [current, upnext]


def invoice_no_gen():
    today, year, month = getTodayYearMonth()
    total_so = formatint(
        len(Invoice.objects.filter(date__month=month)) + 1, leading_zeros_count=4
    )
    mask = Ids.objects.filter(name="INVOICE")[0]
    filler = {
        "year": year,
        "month": month,
        "count": total_so,
        "prefix": mask.prefix,
    }
    current = handleMask(mask.mask, mask.sep, filler)
    mask.current = current
    filler["count"] = formatint(int(filler["count"]) + 1)
    upnext = handleMask(mask.mask, mask.sep, filler)
    mask.upnext = upnext
    mask.save()
    return [current, upnext]


def genWithName(name, id=None, update=False, reset=False):
    today, year, month = getTodayYearMonth()
    model = ModelMapping[name]
    ids = []
    masks = (
        Ids.objects.filter(name=name, id=id) if id else Ids.objects.filter(name=name)
    )
    if model.objects.count() == 0:
        total_so = formatint(1, leading_zeros_count=4)
    else:
        last = model.objects.last()
        if last.createdOn and last.createdOn.month == month:
            total_so = model.objects.values(KeyName[name]).last()[KeyName[name]][-4:]
            total_so = formatint(int(total_so) + 1, leading_zeros_count=4)
        else:
            if name == "PRODUCT":
                total_so = formatint(model.objects.count() + 1, leading_zeros_count=4)
            else:
                total_so = formatint(
                    len(model.objects.filter(createdOn__month=month)) + 1,
                    leading_zeros_count=4,
                )
    for mask in masks:
        filler = {
            "year": year,
            "month": month,
            "count": total_so,
            "prefix": mask.prefix,
        }
        current = handleMask(mask.mask, mask.sep, filler)
        mask.current = current
        filler["count"] = formatint(int(filler["count"]) + 1)
        upnext = handleMask(mask.mask, mask.sep, filler)
        mask.upnext = upnext
        mask.save()
        ids.append([current, upnext])
    if update == False:
        return ids


def recalculateIds():
    l = list(ModelMapping.keys())
    for e in l:
        genWithName(e)
