from django.urls import include, path
from rest_framework import routers
from . import views
from invoicegen_backend import settings
from rest_framework_jwt.views import (
    obtain_jwt_token,
    verify_jwt_token,
    refresh_jwt_token,
)


router = routers.DefaultRouter()
router.register(r"user", views.UserViewSet, basename="user")
router.register(r"company", views.CompanyViewSet, basename="company")
router.register(r"customers", views.CustomerViewSet, basename="customer")
router.register(r"products", views.ProductViewSet, basename="product")
router.register(r"address", views.AddressViewSet, basename="address")
router.register(r"usernote", views.UserNoteViewSet, basename="usernote")
router.register(r"taxes", views.TaxViewSet, basename="taxes")
router.register(
    r"companysettings", views.CompanySettingViewSet, basename="companysettings"
)


urlpatterns = [
    path("", include(router.urls)),
    # Sale Order
    path("saleorders/", views.SaleOrderViewSet.as_view()),
    path("saleorders/<int:id>", views.SaleOrderViewSet.as_view()),
    # Invoice
    path("invoices/", views.InvoiceViewSet.as_view()),
    path("invoices/<int:id>", views.InvoiceViewSet.as_view()),
    # customer address
    path("customersaddresses/", views.CustomerAddressViewSet.as_view()),
    path("customersaddresses/<str:slug>", views.CustomerAddressViewSet.as_view()),
    # idgen
    path("idsmap/", views.IdsMapView.as_view()),
    path("idsmap/<int:id>", views.IdsMapView.as_view()),
    path("serialno/", views.IdsView.as_view()),
    path("serialno/<int:id>", views.IdsView.as_view()),
    # outstanding
    path("customeroutstanding/", views.OutstandingViewSet.as_view()),
    path("customeroutstanding/<int:id>", views.OutstandingViewSet.as_view()),
    # payments
    path("payments/", views.PaymentView.as_view()),
    path("payments/<uuid:id>", views.PaymentView.as_view()),
    # email api
    path("sendmail/", views.sendMail),
    # chart api
    path("getgraphdata/", views.graphData),
    # api auth
    path("api-auth/", include("rest_framework.urls", namespace="rest_framework")),
    path("api-token-auth/", obtain_jwt_token),
    path("api-token-verify/", verify_jwt_token),
    path("api-token-refresh//", refresh_jwt_token),
]