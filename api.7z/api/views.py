from django.db.models import Sum
import pandas as pd
import os, base64
import urllib.parse as uri
from datetime import date, datetime as dt
from django.db.models.functions import TruncMonth
from rest_framework import response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import action, api_view
import time, json
from utils.gmail_api import GMAIL, create_message_with_attachment, send_message
from api.models import *
from api.serializers import *
from api.gen import genWithName, recalculateIds

helper = lambda x: [print(e) for e in dir(x)]
EXR = {
    "message": "No Error",
}
TODAY = date.today()


def jwt_response_payload_handler(token, user=None, request=None):
    userObj = UserSerializer(user, context={"context": request}).data

    return {"token": token, "user": userObj}


def jprint(d):
    return print(json.dumps(d, indent=4))


class UserViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated, IsAdminUser]

    queryset = User.objects.all()
    serializer_class = UserSerializer


class CompanyViewSet(viewsets.ModelViewSet):

    queryset = Company.objects.all()
    serializer_class = CompanySerializer


class CompanyAddressViewSet(viewsets.ModelViewSet):
    queryset = CompanyAddress.objects.all()
    serializer_class = CompanyAddressSerializer


class ProductViewSet(viewsets.ModelViewSet):

    queryset = Product.objects.all()
    serializer_class = ProductSerializer


class CustomerViewSet(viewsets.ModelViewSet):

    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer


class CustomerAddressViewSet(APIView):
    def get(self, request, slug=None):
        data = []
        if slug:
            data = CustomerAddress.objects.filter(id=slug)
        else:
            customerid = request.query_params.get("customer")
            addressType = request.query_params.get("addressType")
            data = CustomerAddress.objects.all()
            if customerid:
                d = CustomerAddress.objects.filter(customer__id=customerid)
                if d.count() > 0:
                    d = [*d]
                    data = d
                else:
                    data = []
            if customerid and addressType:
                d = CustomerAddress.objects.filter(
                    customer__id=customerid, address__addrsType=addressType
                )
                if d.count() > 0:
                    d = [*d]
                    data = d
                else:
                    data = []
        out = CustomerAddressSerializer(data, many=True).data
        return Response(data=out, status=201)

    def post(self, request):
        customer = Customer.objects.get(id=request.data.get("customer"))
        address = Address.objects.get(id=request.data.get("address"))
        if customer and address:
            amap = CustomerAddress.objects.create(customer=customer, address=address)
            amap.save()
            return Response(data=CustomerAddressSerializer(amap).data, status=201)
        else:
            return Response(status=404)

    def put(self, request, slug):
        pass

    def delete(self, request, slug):
        pass


class AddressViewSet(viewsets.ModelViewSet):

    queryset = Address.objects.all()
    serializer_class = AddressSerializer


class UserNoteViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = UserNote.objects.all()
    serializer_class = UserNoteSerializer


class CompanySettingViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated, IsAdminUser]
    queryset = CompanySetting.objects.all()
    serializer_class = CompanySettingSerializer


class PaymentView(APIView):
    def get(self, request):
        data = request.query_params
        customerID = data.get("customerID")
        customer = Customer.objects.get(id=customerID)
        out = []
        if customer:
            customerpayments = CustomerPayment.objects.filter(customer=customer)
            if len(customerpayments) != 0:
                customerpayments = customerpayments.order_by("-payment__updatedOn")
                payments = [cp.payment for cp in customerpayments]
                for e in PaymentSerializer(payments, many=True).data:
                    e["customer"] = CustomerSerializer(customer).data
                    out.append(e)
                return Response(data=out, status=201)
            else:
                return Response(data=[], status=201)
        else:
            return Response(data={"msg": "Customer Not Found"})

    def post(self, request):
        out = {}
        temp_payment = None
        try:
            data = request.data
            customer = Customer.objects.get(id=data["customer"]["id"])
            del data["customer"]
            if request.data["paymentDate"] == "":
                del request.data["paymentDate"]

            temp_payment = Payment(**data)
            serializer = PaymentSerializer(temp_payment)
            serializer = PaymentSerializer(data=serializer.data)
            valid = serializer.is_valid()
            if valid:
                temp_payment.save()
                outstanding = Outstanding.objects.filter(customer=customer)
                if len(outstanding) != 0:
                    outstanding = outstanding[0]
                    outstanding.totalBusinessAmount = (
                        outstanding.totalBusinessAmount or 0.0
                    )
                    outstanding.totalBusinessAmount = (
                        outstanding.totalBusinessAmount + temp_payment.amount
                    )
                    outstanding.dueAmount = outstanding.dueAmount - temp_payment.amount
                    outstanding.save()
                    out = PaymentSerializer(temp_payment).data
                    out["customer"] = CustomerSerializer(customer).data
                cp = CustomerPayment(customer=customer, payment=temp_payment)
                cp.save()
            return Response(data=out, status=201)
        except Exception as e:
            print(e)
            if temp_payment:
                cp = CustomerPayment.objects.filter(payment=temp_payment)[0].customer
                outstanding = cp.outstanding_set.last()

                outstanding.totalBusinessAmount = (
                    outstanding.totalBusinessAmount - temp_payment.amount
                )
                outstanding.dueAmount = outstanding.dueAmount + temp_payment.amount
                outstanding.save()
                temp_payment.delete()
            return Response(data={"msg": "Something Went Wrong"})

    def put(self, request, id):
        out = {}
        payment = Payment.objects.filter(id=id)
        if len(payment) == 0:
            return Response(data={}, status=404)
        else:
            payment = payment[0]
            serializer = PaymentSerializer(
                instance=payment, data=request.data, partial=True
            )
            valid = serializer.is_valid()
            if valid:
                serializer.save()
                out = serializer.data
                out["customer"] = CustomerSerializer(
                    CustomerPayment.objects.filter(payment=payment)[0].customer
                ).data
            else:
                out = serializer.errors
            return Response(data=out, status=201)

    def delete(self, request, id):
        out = {}
        payment = Payment.objects.filter(id=id)
        if payment.count() == 0:
            return Response(data={}, status=404)
        else:
            payment = payment[0]
            out = PaymentSerializer(payment).data
            cp = CustomerPayment.objects.filter(payment=payment)[0].customer
            outstanding = cp.outstanding_set.last()

            outstanding.totalBusinessAmount = (
                outstanding.totalBusinessAmount - payment.amount
            )
            outstanding.dueAmount = outstanding.dueAmount + payment.amount
            outstanding.save()
            payment.delete()
            return Response(data=out, status=201)


@api_view(["POST"])
def sendMail(request):
    file = request.FILES["file"]
    tfn = file.name
    msg = None
    to = request.data["to"]
    subject = request.data["subject"]
    body = request.data["body"]
    sentmsg = {}
    with open(tfn, "wb") as f:
        f.write(file.file.getbuffer())
        msg = create_message_with_attachment(
            to,
            subject,
            body,
            tfn,
        )

        sentmsg = send_message("me", msg)
    os.remove(tfn)
    return Response(data=sentmsg, status=201)


class IdsView(APIView):
    def get(self, request, **kwargs):
        out = []
        data = request.query_params
        if len(data) != 0:
            idfor = data["FOR"]
            genWithName(idfor, update=True)
            ids = Ids.objects.filter(name=idfor)
            if len(ids) != 0:
                serials = IdsSerializer(ids, many=True).data
                out = serials
            else:
                print(out)
        else:
            recalculateIds()
            serials = IdsSerializer(Ids.objects.all(), many=True).data
            out = serials
        return Response(data=out, status=201)

    def post(self, request):
        out = {}
        data = request.data
        serial = Ids(**data)
        serializer = IdsSerializer(serial)
        serializer = IdsSerializer(data=serializer.data)
        valid = serializer.is_valid()
        if valid == True:
            serial.save()
            c, n = genWithName(serial.name, id=serial.id)[0]
            serial.current = c
            serial.upnext = n
            out = IdsSerializer(serial).data
        else:
            out = serializer.errors
        return Response(data=out, status=201)

    def put(self, request, id):
        out = {}
        data = request.data
        serial = Ids.objects.get(id=id)
        serializer = IdsSerializer(instance=serial, data=data, partial=True)
        valid = serializer.is_valid()
        if valid:
            serializer.save()
            out = serializer.data
        else:
            out = serializer.errors
        print(out)
        return Response(data=out, status=201)

    def delete(self, request, id):
        out = {}
        ids = Ids.objects.get(id=id)
        out = IdsSerializer(ids).data
        ids.delete()
        return Response(data=out, status=201)


class IdsMapView(APIView):
    def get(self, request, **kwargs):
        out = []
        data = request.query_params
        if len(data) != 0:
            idname = data["NAME"]
            genWithName(idname)
            ids = IdsMap.objects.filter(name=idname)
            if len(ids) != 0:
                serials = IdsMapSerializer(ids[0]).data
                out = serials
            else:
                out = []
        else:
            serials = IdsMapSerializer(IdsMap.objects.all(), many=True).data
            out = serials
        return Response(data=out, status=201)

    def post(self, request):
        out = {}
        data = request.data
        data["ids"] = Ids.objects.get(id=data["ids"])
        serialmap = IdsMap(**data)
        serializer = IdsMapSerializer(serialmap)
        serializer = IdsMapSerializer(data=serializer.data)
        valid = serializer.is_valid()
        if valid == True:
            serialmap.save()
            out = IdsMapSerializer(serialmap).data
        else:
            out = serializer.errors
        return Response(data=out, status=201)

    def put(self, request, id):
        out = {}
        data = request.data
        serialmap = IdsMap.objects.get(id=id)
        serialmap.ids = Ids.objects.get(id=data["ids"])
        serialmap.save()
        out = IdsMapSerializer(serialmap).data
        return Response(data=out, status=201)

    def delete(self, request, id):
        out = {}
        idsMap = IdsMap.objects.get(id=id)
        out = IdsSerializer(idsMap).data
        idsMap.delete()
        return Response(data=out, status=201)


class SaleOrderViewSet(APIView):
    def get(self, request, id=None):
        out = []
        if id:
            so = SaleOrder.objects.filter(id=id)
            if so.count() > 0:
                out = SaleOrderSerializer(so[0]).data
                out["products"] = SaleOrderProductLineSerializer(
                    so[0].saleorderproductline_set.all(), many=True
                ).data
                out["taxes"] = SaleOrderTaxSerializer(
                    so[0].saleordertax_set.all(), many=True
                ).data
                return Response(data=out, status=201)
            else:
                return Response(status=404)
        else:
            so = SaleOrder.objects.all().order_by("-createdOn")
            for s in so:
                o = SaleOrderSerializer(s).data
                o["products"] = SaleOrderProductLineSerializer(
                    s.saleorderproductline_set.all(), many=True
                ).data
                o["taxes"] = SaleOrderTaxSerializer(
                    s.saleordertax_set.all(), many=True
                ).data
                out.append(o)
            return Response(data=out, status=201)

    def post(self, request):
        out = {}
        data = request.data

        products = data.get("products")
        taxes = data.get("taxes")
        del data["products"]
        del data["taxes"]
        if len(products) != 0:
            so = None
            try:
                data["createdOn"] = dt.now()
                soserializer = SaleOrderSerializer(data=data)
                valid = soserializer.is_valid()
                if valid:
                    so = SaleOrder.objects.create(**soserializer.data)
                    so.save()
                    out = SaleOrderSerializer(so).data
                    out["products"] = []
                    for product in products:
                        product["saleOrder"] = so
                        sop = SaleOrderProductLine(**product)
                        sop.save()
                        out["products"].append(SaleOrderProductLineSerializer(sop).data)
                    out["taxes"] = []
                    if len(taxes) == 0 or taxes == None:
                        taxes = Tax.objects.filter(use=True)
                    else:
                        taxes = [Tax.objects.get(id=tax) for tax in taxes]
                    for tax in taxes:
                        otax = {}
                        otax["saleOrder"] = so
                        otax["taxName"] = tax.code
                        otax["taxPercent"] = tax.percent
                        sot = SaleOrderTax(**otax)
                        sot.save()
                        out["taxes"].append(SaleOrderTaxSerializer(sot).data)

                    # adding saleorder to customer
                    cuso = CustomerSaleOrder(
                        saleOrder=so,
                        customer=Customer.objects.filter(customerId=so.customerId)[0],
                    )
                    cuso.save()
                    os = Outstanding()
                    return Response(data=out, status=201)
                else:
                    return Response(
                        data={"Err": "Something went wrong with saleorder"},
                        status=500,
                    )
            except Exception as e:
                so.delete()
                print(e)
        return Response(data=EXR, status=201)

    def put(self, request, id):
        pass

    def delete(self, request, id):
        so = SaleOrder.objects.filter(id=id)
        if so.count() > 0:
            so.delete()
            return Response(data={"msg": "OK"}, status=201)
        else:
            return Response(data={"msg": "Not Found"}, status=201)


class InvoiceViewSet(APIView):
    def repInv(self, inv):
        out = {}
        out = InvoiceSerializer(inv).data
        out["products"] = InvoiceProductLineSerializer(
            inv.invoiceproductline_set.all(), many=True
        ).data
        out["taxes"] = InvoiceTaxSerializer(inv.invoicetax_set.all(), many=True).data
        return out

    def get(self, request, id=None):
        out = []
        if id:
            inv = Invoice.objects.filter(id=id)
            if inv.count() > 0:
                out = self.repInv(inv[0])
                return Response(data=out, status=201)
            else:
                return Response(status=404)
        else:
            for i in Invoice.objects.all().order_by("-createdOn"):
                out.append(self.repInv(i))
            return Response(data=out, status=201)

    def post(self, request):
        data = request.data
        products = data.get("invoiceProductData") or None
        del data["invoiceProductData"]
        if products is None:
            return Response(status=404)
        data["paid"] = data["paid"] or False
        data["cancelled"] = data["cancelled"] or False
        del data["createdOn"]

        out = {}
        serialized = InvoiceSerializer(data=data)
        if serialized.is_valid():
            purged_data = serialized.validated_data
            inv = Invoice(**purged_data)
            inv.save()  # saving invoice
            out = InvoiceSerializer(inv).data

            [so] = SaleOrder.objects.filter(saleOrderId=inv.soNumber)  # get the so

            # resolve saleorder taxes to invoice taxes
            out["taxes"] = []
            sotaxes = so.saleordertax_set.all()
            for sotax in sotaxes:
                td = SaleOrderTaxSerializer(sotax).data
                del td["saleOrder"]
                del td["id"]
                td["invoice"] = inv
                invtax = InvoiceTax(**td)
                invtax.save()
                out["taxes"].append(InvoiceTaxSerializer(invtax).data)

            out["products"] = []
            # resolve invoice products
            allDone = True
            for product in products:
                pid = product["id"]
                del product["id"]
                product["invProdLineAmount"] = float(product["invProdLineAmount"])
                product["invoice"] = inv
                invprod = InvoiceProductLine(**product)
                invprod.save()
                sop = so.saleorderproductline_set.get(id=pid)
                r = sop.sopDeliveredQty + product["invProdQty"]
                if product["invProdQty"] <= sop.sopQty - sop.sopDeliveredQty:
                    sop.sopDeliveredQty = r
                    sop.save()
                else:
                    inv.delete()
                    return Response(
                        data={"msg": "Invalid invoice product qty"}, status=201
                    )
                out["products"].append(InvoiceProductLineSerializer(invprod).data)
                allDone = sop.sopQty == sop.sopDeliveredQty
            if allDone == True:
                so.completed = True
                so.completedOn = dt.now()
                so.save()
            # adding invoice to saleorder
            soinv = SaleOrderInvoice(invoice=inv, saleOrder=so)
            soinv.save()

            # adding invoice to customer
            cuinv = CustomerInvoice(
                invoice=inv,
                customer=Customer.objects.filter(customerId=inv.customerId)[0],
            )
            cuinv.save()

            return Response(data=out, status=201)
        else:
            return Response(data=serialized.errors, status=201)

    def put(self, request, id):
        pass

    def delete(self, request, id):
        print(id)
        inv = Invoice.objects.filter(id=id)
        if inv.count() > 0:
            inv = inv[0]
            so = SaleOrder.objects.filter(saleOrderId=inv.soNumber)[0]
            for p in inv.invoiceproductline_set.all():
                sop = so.saleorderproductline_set.filter(sopCode=p.invProdCode)[0]
                sop.sopDeliveredQty = sop.sopDeliveredQty - p.invProdQty
                so.completed = sop.sopDeliveredQty == sop.sopQty
                so.save()
                sop.save()
            inv.delete()
            return Response(
                data={
                    "invoiceId": inv.invoiceId,
                    "msg": f"Success: {inv.invoiceId} has been deleted.",
                },
                status=201,
            )
        else:
            return Response(data={"msg": "Not Found"}, status=201)


class TaxViewSet(viewsets.ModelViewSet):

    queryset = Tax.objects.all()
    serializer_class = TaxSerializer


class OutstandingViewSet(APIView):
    def get(self, request, id=None):
        out = []
        cid = request.query_params.get("customer") or None
        if id:
            res = Outstanding.objects.filter(id=id)
            if cid:
                res = Outstanding.objects.filter(
                    id=id, customer=Customer.objects.get(id=cid)
                )
            if res.count() > 0:
                return Response(data=OutstandingSerializer(res[0]).data, status=201)
            else:
                return Response(status=404)
        if cid:
            res = Outstanding.objects.filter(customer=Customer.objects.get(id=cid))
            customer = Customer.objects.get(id=cid)
            if res.count() > 0:
                res = res[0]
                recalc = request.query_params.get("recalculate") or False
                if recalc == "true":
                    customer = Customer.objects.get(id=cid)
                    dueAmount = customer.customerinvoice_set.filter(
                        invoice__paid=False
                    ).aggregate(Sum("invoice__invoiceAmountWithTax"))[
                        "invoice__invoiceAmountWithTax__sum"
                    ]
                    paidAmount = customer.customerpayment_set.all().aggregate(
                        Sum("payment__amount")
                    )["payment__amount__sum"]
                    res.dueAmount = dueAmount - paidAmount
                    res.totalBusinessAmount = paidAmount
                    res.save()
                out = OutstandingSerializer(res).data
                out["soCount"] = customer.customersaleorder_set.count()
                out["invoiceCount"] = customer.customerinvoice_set.count()
                return Response(data=out, status=201)
            else:
                dueAmount = customer.customerinvoice_set.filter(
                    invoice__paid=False
                ).aggregate(Sum("invoice__invoiceAmountWithTax"))[
                    "invoice__invoiceAmountWithTax__sum"
                ]
                totalBusinessAmount = (
                    customer.customerinvoice_set.filter(invoice__paid=True).aggregate(
                        Sum("invoice__invoiceAmountWithTax")
                    )["invoice__invoiceAmountWithTax__sum"]
                    or 0.0
                )
                cos = Outstanding(
                    customer=customer,
                    dueAmount=dueAmount,
                    totalBusinessAmount=totalBusinessAmount,
                )
                cos.save()
                out = OutstandingSerializer(cos).data
                out["soCount"] = customer.customersaleorder_set.count()
                out["invoiceCount"] = customer.customerinvoice_set.count()
                return Response(data=out, status=201)


@api_view(["GET"])
def graphData(request):
    out = {
        "labels": [],
        "data": [],
    }
    mp = {"INVOICE": Invoice, "SALEORDER": SaleOrder, "PAYMENT": Payment}
    dtmp = {
        "INVOICE": "invoiceAmountWithTax",
        "SALEORDER": "totalAmount",
        "PAYMENT": "amount",
    }
    lbKey = request.query_params.get("labelKey") or "createdOn"
    name = request.query_params.get("name") or "PAYMENT"
    dtKey = request.query_params.get("dataKey") or dtmp[name]
    vals = mp[name].objects.values(lbKey, dtKey)
    for val in vals:
        k = (
            val[lbKey].strftime("%m/%d/%Y, %H:%M:%S")
            if lbKey == "createdOn"
            else val[lbKey]
        )
        out["labels"].append(k)
        out["data"].append(val[dtKey])
    return Response(data=out, status=201)