import datetime
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import uuid, datetime


def today():
    # return datetime.datetime.now()
    return timezone.localtime(timezone.now())


class Ids(models.Model):
    name = models.TextField(null=True, blank=True)
    prefix = models.TextField(default="ESAR")
    current = models.TextField(null=True, blank=True)
    upnext = models.TextField(null=True, blank=True)
    count = models.IntegerField(default=0)
    sep = models.TextField(default="", null=True, blank=True)
    mask = models.TextField(
        default="{prefix}{year}{month}{count}", null=True, blank=True
    )
    modifiedOn = models.DateTimeField(auto_now=True)


class Address(models.Model):
    code = models.CharField(max_length=20, blank=True, unique=True)
    addrsType = models.CharField(max_length=20, blank=True, null=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    line1 = models.CharField(max_length=100, blank=True, null=True)
    line2 = models.CharField(max_length=100, blank=True, null=True)
    line3 = models.CharField(max_length=100, blank=True, null=True)
    state = models.CharField(max_length=50)
    stateCode = models.IntegerField(default=22, blank=True, null=True)
    city = models.CharField(max_length=50)
    postalCode = models.CharField(max_length=10, blank=True, null=True)
    typeCode = models.CharField(max_length=20, blank=True, null=True)
    phone = models.CharField(max_length=13, blank=True)
    fax = models.CharField(max_length=20, blank=True)
    email = models.EmailField(max_length=50, blank=True)
    gstin = models.CharField(max_length=15, blank=True, null=True)
    panNo = models.CharField(default="", max_length=10, blank=True)
    createdBy = models.EmailField(blank=True)
    createdOn = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    modifiedBy = models.EmailField(blank=True)
    modifiedOn = models.DateTimeField(auto_now=True, null=True, blank=True)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Addresss"

    def __str__(self):
        return self.name


class Customer(models.Model):
    id = models.UUIDField(default=uuid.uuid4, primary_key=True, editable=False)
    customerId = models.CharField(max_length=30, null=True, blank=True, unique=True)
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=50, blank=True)
    phone = models.CharField(max_length=13, blank=True)
    gstin = models.CharField(max_length=15, blank=True, null=True)
    panNo = models.CharField(max_length=10, default="")
    createdOn = models.DateTimeField(default=today, null=True, blank=True)
    createdBy = models.EmailField(blank=True)
    modifiedOn = models.DateTimeField(auto_now=True, blank=True)
    modifiedBy = models.EmailField(blank=True)


class CustomerAddress(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    address = models.ForeignKey(Address, on_delete=models.CASCADE)


class Company(models.Model):
    id = models.UUIDField(default=uuid.uuid4, primary_key=True, editable=False)
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, blank=True)
    address = models.ForeignKey(
        Address, null=True, blank=True, on_delete=models.CASCADE
    )
    logo = models.ImageField(null=True, blank=True, upload_to="logo")
    email = models.EmailField(max_length=50, blank=True)
    phone = models.CharField(max_length=13, blank=True)
    gstin = models.CharField(max_length=15, blank=True, null=True)
    panNo = models.CharField(max_length=10, default="", blank=True)

    def __str__(self):
        return f"{self.name} | {self.gstin}"


class CompanyAddress(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    address = models.ForeignKey(Address, on_delete=models.CASCADE)


class CompanyCustomer(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)


class Product(models.Model):
    code = models.CharField(max_length=20, blank=True)
    name = models.CharField(max_length=20)
    description = models.CharField(max_length=50, blank=True)
    hsnCode = models.CharField(max_length=20, blank=True)
    uom = models.CharField(max_length=5)
    rate = models.CharField(max_length=20)
    createdOn = models.DateTimeField(default=today, blank=True)


class CompanyProduct(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)


# SALE ORDER
class SaleOrder(models.Model):
    # id and number
    saleOrderId = models.CharField(max_length=30, unique=True)
    poNumber = models.CharField(max_length=50, blank=True)
    poDate = models.DateField(null=True, blank=True)
    customerId = models.CharField(max_length=50, blank=True)

    # comapny
    orgName = models.CharField(max_length=100, blank=True)
    orgAddrsLine1 = models.TextField(max_length=200, blank=True)
    orgAddrsLine2 = models.TextField(max_length=200, blank=True)
    orgAddrsLine3 = models.TextField(max_length=200, blank=True)
    orgEmail = models.EmailField(null=True, blank=True)
    orgPhone = models.CharField(max_length=13, blank=True)
    orgFax = models.CharField(max_length=20, blank=True)
    orgState = models.CharField(max_length=50, blank=True)
    orgCity = models.CharField(max_length=50, blank=True)
    orgPostalCode = models.CharField(max_length=8, blank=True)
    orgGSTIN = models.CharField(max_length=15, blank=True)
    orgLogo = models.URLField(null=True, blank=True)
    orgPanNo = models.CharField(max_length=10, default="")

    # billing
    billToName = models.CharField(max_length=50, blank=True)
    billToAddrsLine1 = models.CharField(max_length=50, blank=True)
    billToAddrsLine2 = models.CharField(max_length=50, blank=True)
    billToAddrsLine3 = models.CharField(max_length=50, blank=True)
    billToState = models.CharField(max_length=50, blank=True)
    billToCity = models.CharField(max_length=50, blank=True)
    billToPostalCode = models.CharField(max_length=8, blank=True)
    billToPhone = models.CharField(max_length=50, blank=True)
    billToEmail = models.CharField(max_length=50, blank=True)
    billToPanNo = models.CharField(max_length=50, blank=True)
    billToGSTIN = models.CharField(max_length=50, blank=True)
    # shipping
    shipToName = models.CharField(max_length=50, blank=True)
    shipToAddrsLine1 = models.CharField(max_length=50, blank=True)
    shipToAddrsLine2 = models.CharField(max_length=50, blank=True)
    shipToAddrsLine3 = models.CharField(max_length=50, blank=True)
    shipToState = models.CharField(max_length=50, blank=True)
    shipToCity = models.CharField(max_length=50, blank=True)
    shipToPostalCode = models.CharField(max_length=8, blank=True)
    shipToPhone = models.CharField(max_length=50, blank=True)
    shipToEmail = models.CharField(max_length=50, blank=True)
    shipToPanNo = models.CharField(max_length=50, blank=True)
    shipToGSTIN = models.CharField(max_length=50, blank=True)

    totalAmount = models.FloatField(default=0.0)
    expired = models.BooleanField(default=False)
    status = models.CharField(default="OPEN", max_length=10)
    dueDate = models.DateField(auto_now=True)
    completed = models.BooleanField(default=False)
    paid = models.BooleanField(default=False)
    completedOn = models.DateField(null=True, blank=True)
    createdOn = models.DateTimeField(default=today, null=True, blank=True)
    createdBy = models.EmailField(blank=True)


class SaleOrderProductLine(models.Model):
    saleOrder = models.ForeignKey(SaleOrder, on_delete=models.CASCADE)
    sopCode = models.CharField(max_length=20, blank=True)
    sopName = models.CharField(max_length=20)
    sopDescription = models.CharField(max_length=50, blank=True)
    sopHsnCode = models.CharField(max_length=20, blank=True)
    sopUom = models.CharField(max_length=5)
    sopRate = models.FloatField(max_length=0.0)
    sopQty = models.FloatField(default=0.0)
    sopDeliveredQty = models.FloatField(default=0.0)


class SaleOrderTax(models.Model):
    saleOrder = models.ForeignKey(SaleOrder, on_delete=models.CASCADE)
    taxName = models.CharField(max_length=20, blank=True)
    taxPercent = models.FloatField(default=0.0, blank=True)


class Invoice(models.Model):
    invoiceId = models.CharField(max_length=30, unique=True)
    soNumber = models.CharField(max_length=50, blank=True)
    poNumber = models.CharField(max_length=50, blank=True)
    deliveryDate = models.DateField(blank=True, null=True)
    customerId = models.CharField(max_length=20, blank=True)

    # comapny
    orgName = models.CharField(max_length=100, blank=True)
    orgAddrsLine1 = models.TextField(max_length=200, blank=True)
    orgAddrsLine2 = models.TextField(max_length=200, blank=True)
    orgAddrsLine3 = models.TextField(max_length=200, blank=True)
    orgEmail = models.EmailField(null=True, blank=True)
    orgPhone = models.CharField(max_length=13, blank=True)
    orgFax = models.CharField(max_length=20, blank=True)
    orgCity = models.CharField(max_length=50, blank=True)
    orgPostalCode = models.CharField(max_length=10, blank=True)
    orgState = models.CharField(max_length=50, blank=True)
    orgGSTIN = models.CharField(max_length=15, blank=True)
    orgLogo = models.URLField(null=True, blank=True)
    orgPanNo = models.CharField(max_length=10, default="")

    # billing
    billToName = models.CharField(max_length=50, blank=True)
    billToAddrsLine1 = models.CharField(max_length=50, blank=True)
    billToAddrsLine2 = models.CharField(max_length=50, blank=True)
    billToAddrsLine3 = models.CharField(max_length=50, blank=True)
    billToState = models.CharField(max_length=50, blank=True)
    billToCity = models.CharField(max_length=50, blank=True)
    billToPostalCode = models.CharField(max_length=8, blank=True)
    billToPhone = models.CharField(max_length=50, blank=True)
    billToEmail = models.CharField(max_length=50, blank=True)
    billToPanNo = models.CharField(max_length=50, blank=True)
    billToGSTIN = models.CharField(max_length=50, blank=True)
    # shipping
    shipToName = models.CharField(max_length=50, blank=True)
    shipToAddrsLine1 = models.CharField(max_length=50, blank=True)
    shipToAddrsLine2 = models.CharField(max_length=50, blank=True)
    shipToAddrsLine3 = models.CharField(max_length=50, blank=True)
    shipToState = models.CharField(max_length=50, blank=True)
    shipToCity = models.CharField(max_length=50, blank=True)
    shipToPostalCode = models.CharField(max_length=8, blank=True)
    shipToPhone = models.CharField(max_length=50, blank=True)
    shipToEmail = models.CharField(max_length=50, blank=True)
    shipToPanNo = models.CharField(max_length=50, blank=True)
    shipToGSTIN = models.CharField(max_length=50, blank=True)

    transportMode = models.CharField(default="Road", max_length=20)
    transporterCode = models.CharField(default="", max_length=20, blank=True)
    transporterName = models.CharField(default="", max_length=50, blank=True)
    vehicleRegNo = models.CharField(default="", max_length=50)
    lrOrRrNo = models.CharField(default="", max_length=50, blank=True)
    lrOrRrDate = models.DateField(null=True, blank=True)
    ewayBillNo = models.CharField(default="", max_length=50, blank=True)
    ewayBillDatetime = models.DateTimeField(blank=True, null=True)
    placeOfSupply = models.CharField(default="Raipur", max_length=50)
    perticulars = models.TextField(default="", max_length=200, blank=True)
    paymentTerms = models.TextField(default="", max_length=1000)
    ticketNo = models.CharField(max_length=40, blank=True, null=True)
    reverseTax = models.BooleanField(default=False)
    invoiceAmount = models.FloatField(default=0.0)
    invoiceAmountWithTax = models.FloatField(default=0.0)
    paid = models.BooleanField(default=False)
    cancelled = models.BooleanField(default=False)
    cancelReason = models.CharField(max_length=1000, blank=True, default="")
    createdOn = models.DateTimeField(default=today, null=True, blank=True)
    createdBy = models.EmailField(blank=True)


class InvoiceProductLine(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE)
    invProdCode = models.CharField(max_length=20, blank=True)
    invProdName = models.CharField(max_length=20)
    invProdDescription = models.CharField(max_length=50, blank=True, default="")
    invProdHsnCode = models.CharField(max_length=20, blank=True, default="")
    invProdUom = models.CharField(max_length=5, default="")
    invProdQty = models.FloatField(default=0.0)
    invProdRate = models.FloatField(default=0.0)
    invProdLineAmount = models.FloatField(default=0.0)


class InvoiceTax(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE)
    taxName = models.CharField(max_length=20, blank=True)
    taxPercent = models.FloatField(default=0.0, blank=True)


class CustomerSaleOrder(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    saleOrder = models.ForeignKey(SaleOrder, on_delete=models.CASCADE)


class CustomerInvoice(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE)


class SaleOrderInvoice(models.Model):
    saleOrder = models.ForeignKey(SaleOrder, on_delete=models.CASCADE)
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE)


class UserNote(models.Model):
    user = models.ForeignKey(
        User,
        verbose_name="CreatedBy",
        on_delete=models.CASCADE,
    )
    title = models.TextField(default="", blank=True, null=True, max_length=50)
    note = models.TextField(default="", blank=True, null=True, max_length=200)
    createdOn = models.DateTimeField(default=today, blank=True, null=True)
    updatedOn = models.DateTimeField(auto_now=True, blank=True, null=True)


class CompanySetting(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    emailBody = models.TextField(default="", blank=True, null=True, max_length=1000)
    tc = models.TextField(max_length=2000, default="", blank=True)
    createdOn = models.DateTimeField(default=today, blank=True, null=True)
    updatedOn = models.DateTimeField(auto_now=True, blank=True, null=True)


class Payment(models.Model):
    id = models.UUIDField(default=uuid.uuid4, primary_key=True, editable=False)
    mode = models.TextField(default="UPI", max_length=20)
    refUtrChequeNo = models.TextField(blank=True, null=True, max_length=100)
    bank = models.TextField(blank=True, null=True, max_length=100)
    paymentDate = models.DateField(blank=True, null=True)
    amount = models.FloatField(default=0.0, blank=True)
    remark = models.TextField(blank=True, null=True, max_length=100)
    createdOn = models.DateTimeField(default=today, null=True, blank=True)
    updatedOn = models.DateTimeField(auto_now=True, null=True, blank=True)

    class Meta:
        verbose_name = "Payment"
        verbose_name_plural = "Payments"

    def __str__(self):
        return f"{self.customer.name}|{self.mode}"


class CustomerPayment(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE)


class Outstanding(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    dueAmount = models.FloatField(default=0.0, blank=True)
    totalBusinessAmount = models.FloatField(default=0.0, null=True, blank=True)
    createdOn = models.DateTimeField(default=today, null=True, blank=True)
    updatedOn = models.DateTimeField(default=today, null=True, blank=True)

    class Meta:
        verbose_name = "Outstanding"
        verbose_name_plural = "Outstandings"

    def __str__(self):
        print(self.customer)
        return f"{self.customer} | {self.dueAmount}"


class IdsMap(models.Model):
    name = models.CharField(null=True, blank=True, max_length=20, unique=True)
    ids = models.ForeignKey(Ids, on_delete=models.CASCADE)


class Tax(models.Model):
    code = models.CharField(max_length=10)
    fullname = models.CharField(max_length=50, blank=True)
    percent = models.FloatField(default=0.0)
    use = models.BooleanField(default=False)
    createdOn = models.DateTimeField(auto_now_add=True)
    updatedOn = models.DateTimeField(auto_now=True)
